import vrplib
import pandas as pd
from math import log10
import os

FOLDER_NAME : str = 'C:/Users/BompolB/Desktop/SWI_TruckOptimization_CB_2024/src/branch_and_price/'

def get_all_instance_names(folder_name : str) -> list[str]:
    return sorted(set([f_[:-4] for f_ in os.listdir(folder_name) if os.path.isfile(f'{folder_name}/{f_}')])) 

def build_xlsx_instance(instance_name : str) -> None:
    instance : dict = vrplib.read_instance(f'vrp_instances/{instance_name}.vrp')
    solution : dict = vrplib.read_solution(f'vrp_instances/{instance_name}.sol')

    truck_cap : int = max(len(l_) for l_ in solution['routes']) # instance['capacity']
    nb_cust : int = len(solution['routes'])
    nb_supp : int = instance['dimension'] - nb_cust
    min_collect : int = nb_cust

    nb_zeros_cust : int = int(log10(nb_cust - 1) + 1)
    nb_zeros_supp : int = int(log10(nb_supp - 1) + 1)

    cust_df : pd.DataFrame = pd.DataFrame(columns = ['custNo', 'locX', 'locY', 'demand'])
    for c_, (cx_, cy_) in enumerate(instance['node_coord'][:nb_cust]):
        cust_df.loc[len(cust_df.index)] = [f'c{str(c_).zfill(nb_zeros_cust)}', cx_, cy_, 1]

    supp_df : pd.DataFrame = pd.DataFrame(columns = ['suppNo', 'locX', 'locY', 'supply'])
    for s_, (sx_, sy_) in enumerate(instance['node_coord'][nb_cust:]):
        supp_df.loc[len(supp_df.index)] = [f's{str(s_).zfill(nb_zeros_supp)}', sx_, sy_, 1]

    param_df : pd.DataFrame = pd.DataFrame({'min_collect' : [min_collect], 'truck_cap' : truck_cap})

    output_filename = f'vrp_xlsx_instances/{instance_name[0]}/{instance_name}.xlsx'
    with pd.ExcelWriter(output_filename) as xlWriter:
        param_df.to_excel(xlWriter, sheet_name = 'parameters', index = False)
        cust_df.to_excel(xlWriter, sheet_name = 'customers', index = False)
        supp_df.to_excel(xlWriter, sheet_name = 'suppliers', index = False)

if __name__ == '__main__':
    for iname_ in get_all_instance_names(FOLDER_NAME + 'vrp_instances'):
        if not os.path.exists(f'{FOLDER_NAME}vrp_xlsx_instances/{iname_[0]}'):
            os.mkdir(f'{FOLDER_NAME}vrp_xlsx_instances/{iname_[0]}')

        print(f'Building instance {iname_}...', end = ' ')
        build_xlsx_instance(iname_)
        print('Done !')