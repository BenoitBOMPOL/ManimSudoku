"""
    Solve the generalization of the first model
    Subtour eliminations are generated if necessary
"""

from column_init import compute_distances
from misc import *
from ortools.linear_solver import pywraplp
import networkx as nx

DEPOT = 'depot'

def build_model(settings_file : str,
                subtours : list[list[tuple]]) -> tuple[pywraplp.Solver, dict] | None:
    """
        Constructs the base model from the Excel prototype
        No subtour included, as they are added in a function
        (that is yet to write)
    """
    # Constants
    min_collect : int = get_min_collect(settings_file)
    truck_cap   : int = get_truck_cap(settings_file)
    supp_amount : dict[str, float] = get_supp_amount(settings_file)
    cust_demand : dict[str, float] = get_cust_demand(settings_file)

    nb_trucks : int = len(cust_demand)
    trucks : range = range(nb_trucks)
    nb_cust : int = len(cust_demand)
    nb_supp : int = len(supp_amount)

    cust_coords : dict[str, tuple[float, float]] = get_cust_coords(settings_file)
    supp_coords : dict[str, tuple[float, float]] = get_supp_coords(settings_file)
    all_coords : dict[str, tuple[float, float]] = {l_ : cust_coords[l_] if l_ in cust_coords else supp_coords[l_] for l_ in list(cust_coords.keys()) + list(supp_coords.keys())}
    distances : dict[tuple[str, str], float] = compute_distances(all_coords, cust_coords.keys(), supp_coords.keys())
    
    # Invoking the solver
    model : pywraplp.Solver = pywraplp.Solver.CreateSolver('SAT')
    if not model:
        return None
    # model.EnableOutput()

    # Creating the variables
    locations = [DEPOT] + list(cust_demand.keys()) + list(supp_amount.keys())

    x : dict[tuple[str, str, str], pywraplp.Solver.BoolVar] = {}
    for (u, v) in [(u_, v_) for u_ in locations for v_ in locations]:
        c1 = u == v
        c2 = (u == DEPOT) and (v in supp_amount)
        c3 = (u in cust_demand) and (v in cust_demand)
        c4 = (u in supp_amount) and (v in cust_demand)
        if not(c1 or c2 or c3 or c4):
            for t in trucks:
                x[(u, v, t)] = model.BoolVar(f'x{u, v, t}')

    # 5. Balance equation
    for (v, t) in [(v_, t_) for v_ in locations for t_ in trucks]:
        model.Add(sum(x[(u_, v, t)] for u_ in locations if (u_, v, t) in x.keys()) == sum(x[(v, w_, t)] for w_ in locations if (v, w_, t) in x.keys()))
    
    # Customers
    # 6. To each truck is assigned a customer
    for t in trucks:
        model.Add(sum(x[(DEPOT, c_, t)] for c_ in cust_demand) == 1)
    
    # 7. Each customer is visited once
    for c in cust_demand:
        model.Add(sum(x[(DEPOT, c, t_)] for t_ in trucks) == 1)
    
    # 8. Truck capacities are satisfied
    for (t, c) in [(t_, c_) for t_ in trucks for c_ in cust_demand]:
        model.Add(x[(DEPOT, c, t)] * cust_demand[c] <= truck_cap)
    
    # 9. Each supplier is visited at most once
    for s in supp_amount:
        model.Add(sum(x[(u_, s, t_)] for t_ in trucks for u_ in locations if (u_, s, t_) in x.keys()) <= 1)

    # 10. Truck capacities are satisfied
    for t in trucks:
        model.Add(sum(supp_amount[s_] * x[(u_, s_, t)] for s_ in supp_amount for u_ in locations if (u_, s_, t) in x.keys()) <= truck_cap)
    
    # 11. Enough recycled paper has been collected
    model.Add(sum(supp_amount[s_] * x[(u_, s_, t_)] for s_ in supp_amount for u_ in locations for t_ in trucks if (u_, s_, t_) in x.keys()) >= min_collect)

    # 12. Subtour elimination
    for stour_ in subtours:
        sec_cut = sum(x[(u_, v_, t_)] for u_ in stour_ for v_ in stour_ for t_ in trucks if (u_, v_, t_) in x.keys()) <= len(stour_) - 1
        model.Add(sec_cut)

    overall_distance = sum(x[(u_, v_, t_)] * distances[(u_, v_)] for u_ in locations for v_ in locations for t_ in trucks if (u_, v_) in distances.keys() and (u_, v_, t_) in x.keys())
    model.Minimize(overall_distance)
    status = model.Solve()
    if status not in [pywraplp.Solver.OPTIMAL]:
        return None
    return model, x

def get_new_subtours(settings_file : str, prev_subtours : list[list[tuple]]):
    nb_cust : int = get_nb_cust(settings_file)
    supp_amount : dict[str, float] = get_supp_amount(settings_file)

    output = build_model(settings_file, prev_subtours)
    if output is None:
        return None
    model, arcs = output
    model.Solve()
    new_subtours : list[list[tuple]] = []
    for t in range(nb_cust):
        edges = []
        for (s1, s2) in [(s1_, s2_) for s1_ in supp_amount for s2_ in supp_amount if (s1_, s2_, t) in arcs.keys()]:
            if arcs[(s1, s2, t)].solution_value():
                edges.append((s1, s2))
        supp_sdg = nx.DiGraph(edges)
        str_coco = list(nx.strongly_connected_components(supp_sdg))
        for subt in [subt_ for subt_ in str_coco if len(subt_) > 1]:
            new_subtours.append(subt)
    return new_subtours, model, arcs

def solve_ortools(settings_file : str):
    has_finished = False
    subtours = []
    iter_no = 1
    arcs : dict = {}
    model : pywraplp.Solver | None = None
    while not has_finished:
        output = get_new_subtours(settings_file, subtours)
        if output is None:
            has_finished = True
        else:
            next_subtours, model, arcs = output
            has_finished = len(next_subtours) == 0
            subtours.extend(next_subtours)
            iter_no += 1

    if model is None:
        return None
    # nb_trucks = get_nb_cust(settings_file)
    # cust_demand = get_cust_demand(settings_file)
    # supp_amount = get_supp_amount(settings_file)
    # locations = [DEPOT] + list(cust_demand.keys()) + list(supp_amount.keys())
    # for t in range(nb_trucks):
    #     print(f'Truck no. {t}')
    #     arcs_taken = [(u_, v_) for u_ in locations for v_ in locations if (u_, v_, t) in arcs.keys() and arcs[(u_, v_, t)].solution_value()]
    #     for (u, v) in arcs_taken:
    #         print(f'\t{u} -> {v}')
    return model.Objective().Value()

if __name__ == '__main__':
    instance_file : str = input('input filename :')
    objval = solve_ortools(instance_file)
    print(objval)