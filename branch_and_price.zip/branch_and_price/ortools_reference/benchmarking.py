"""
    Time benchmarking
"""
import os
from time import perf_counter_ns
import pandas as pd
from ortools_solve import solve_ortools
from IPython.display import display

FOLDER_NAME : str = 'C:/Users/BompolB/Desktop/SWI_TruckOptimization_CB_2024/src/branch_and_price/vrp_xlsx_instances'

def get_all_instance_names(folder_name : str) -> list[str]:
    return sorted(set([f_ for f_ in os.listdir(folder_name) if os.path.isfile(f'{folder_name}/{f_}')])) 

def run_instance(instance_filename : str) -> list[float]:
    '''
        Runs the [instance_filename] on both
            - OR-Tools as a reference
            - BranchPrice implementation
        
        Returns : 
            [time_bp, opt_bp, calls_to_pricer]
    '''
    t1_ort = perf_counter_ns()
    t2_ort = float('inf')
    bp_output = solve_ortools(instance_filename)
    if bp_output:
        t2_ort = perf_counter_ns()

    results : list[float] = [(t2_ort - t1_ort) * 1E-9, None]
    if bp_output:
        results[1] = bp_output
    return results

def main(folder_name : str, output_filename : str):
    benchmark_df : pd.DataFrame = pd.DataFrame(columns = ['instance_name', 'time_ort', 'opt_ort'])
    for instance_name in get_all_instance_names(folder_name):
        print(f'Instance {instance_name}')
        instance_filename = folder_name + '/' + instance_name
        new_row = [instance_name[:-5]] + run_instance(instance_filename)
        benchmark_df.loc[len(benchmark_df.index)] = new_row
        display(benchmark_df)
        print()
        benchmark_df.to_excel(output_filename, index=False)

if __name__ == '__main__':
    instance_subset = input('Set to cover in the benchmark :')
    main(FOLDER_NAME + f'/{instance_subset}', f'benchmark_set_{instance_subset}.xlsx')
