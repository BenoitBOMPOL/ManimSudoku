"""
    Branch and Price solver of the generalized model
        One customer
        Multiple suppliers
        No time windows
"""

from misc import *
from column_init import generate_first_columns, compute_distances, create_column
from structs import StrongBranchingNode
from restricted_master_problem import solve_restricted_master_problem
from pricing import solve_heuristic_pricing, solve_heuristic_pricing_v2, solve_heuristic_pricing_v3
from time import perf_counter_ns

TOLERANCE = 1E-14

# Define some status
ERROR_CODE = 0
ADD_COLUMN = 1
OPT_INTSOL = 2
NEW_BRANCH = 3

STATUS_NAME = {
    ERROR_CODE : 'Error',
    ADD_COLUMN : 'AddColumn',
    OPT_INTSOL : 'IntOptimalFound',
    NEW_BRANCH : 'Branching'
}

def branch_and_price(
        settings_file : str,
        columns : list[tuple[int]],
        distances : dict[tuple[str, str], float],
        node : StrongBranchingNode):
    """
        Applies the algorithm at a given node, does one iteration
    """
    print('\tStep 1 - Solving the Restricted Master Problem')
    output_rmp = solve_restricted_master_problem(settings_file, node.columns, node.added_cuts)
    if output_rmp is None:
        print('\t\tThe RMP was not solved.')
        node.status = STATUS_NAME[ERROR_CODE]
        return ERROR_CODE, None
    solution, dual_values, obj_val = output_rmp
    print('\tStep 2 - Solve the Pricing Problem')
    forbidden_routes = [transform_column_to_arcs(col_, get_nb_cust(settings_file), get_nb_supp(settings_file)) for col_ in columns]
    output_pricing = solve_heuristic_pricing_v2(settings_file, dual_values, forbidden_routes, distances)
    node.nb_calls_pr += 1
    if output_pricing is None:
        node.status = STATUS_NAME[ERROR_CODE]
        return ERROR_CODE, None
    reduced_cost, arcs_newcol = output_pricing
    if reduced_cost < 0:
        print(f'\tMinimum reduced cost = {reduced_cost} is < 0.')
        new_column = create_column(len(columns[0]), arcs_newcol, get_nb_cust(settings_file), get_nb_supp(settings_file))
        node.status = STATUS_NAME[ADD_COLUMN]
        return ADD_COLUMN, new_column
    else:
        print(f'\tCurrent objective value found : {obj_val}')
        node.lr_rmp = obj_val
        is_fully_integral : bool = all(solution[colh_].is_integer() for colh_ in solution)
        # Solution is integer
        if is_fully_integral:
            print('\tA fully integral optimal solution has been found !')
            node.status = STATUS_NAME[OPT_INTSOL]
            return OPT_INTSOL, solution, obj_val
        float_vals = {colh_ : solution[colh_] for colh_ in solution if not solution[colh_].is_integer()}
        beyond_tol = {colh_ : min(abs(solution[colh_] - int(solution[colh_])), abs(solution[colh_] - int(solution[colh_]) - 1)) for colh_ in float_vals.keys()}
        # Solution is integer up to a certain tolerance
        if max(beyond_tol.values()) < TOLERANCE:
            print(f'\tAn integral optimal solution (up to {TOLERANCE}) has been found !')
            node.status = STATUS_NAME[OPT_INTSOL]
            intsolution : dict[int, int] = {}
            for colh_ in solution:
                if solution[colh_].is_integer():
                    intsolution[colh_] = solution[colh_]
                elif abs(solution[colh_] - int(solution[colh_])) < TOLERANCE:
                    intsolution[colh_] = int(solution[colh_])
                else:
                    intsolution[colh_] = 1 + int(solution[colh_])
            return OPT_INTSOL, intsolution, obj_val
        # Branching
        half_ordering = sorted(solution, key = lambda v_ : abs(solution[v_] - int(solution[v_]) - 0.5))
        closest_to_half = half_ordering[0]
        print(f'\t\tBranching on θ[{closest_to_half}] = {solution[closest_to_half]}')
        print(f'\t\t\t{closest_to_half, "leq", int(solution[closest_to_half])}')
        left_cut = (closest_to_half, 'leq', int(solution[closest_to_half]))
        print(f'\t\t\t{closest_to_half, "geq", 1 + int(solution[closest_to_half])}')
        right_cut = (closest_to_half, 'geq', 1 + int(solution[closest_to_half]))
        node.status = STATUS_NAME[NEW_BRANCH]
        return NEW_BRANCH, left_cut, right_cut, obj_val, closest_to_half, solution[closest_to_half]
        
def solver_branchandprice(settings_file : str) -> None | tuple[dict[int, float], float, list[tuple[int]], list[StrongBranchingNode]]:
    supp_amounts : dict[str, float] = get_supp_amount(settings_file)
    truck_cap : int = get_truck_cap(settings_file)
    min_collect : int = get_min_collect(settings_file)

    cust_coords : dict[str, tuple[float, float]] = get_cust_coords(settings_file)
    supp_coords : dict[str, tuple[float, float]] = get_supp_coords(settings_file)
    all_coords : dict[str, tuple[float, float]] = {l_ : cust_coords[l_] if l_ in cust_coords else supp_coords[l_] for l_ in list(cust_coords.keys()) + list(supp_coords.keys())}

    distances : dict[tuple[str, str], float] = compute_distances(all_coords, cust_coords.keys(), supp_coords.keys())
    columns : list[tuple[int]] = generate_first_columns(distances, list(cust_coords.keys()), truck_cap, supp_amounts, min_collect)
    if columns is None:
        return
    print('+++ Initialization successful +++')
    print(f'Cost of the initialization : {round(sum(get_cost(cust_coords, supp_coords, distances, col_) for col_ in columns), 3)}')
    for philcol_ in columns:
        print(transform_column_to_arcs(philcol_, len(cust_coords), len(supp_coords)))
    print()

    cuts : list[tuple[int, str, int]] = []
    starting_node : StrongBranchingNode = StrongBranchingNode(0, columns, cuts)
    nodes_to_explore : list[StrongBranchingNode] = [starting_node]
    node_index = 0
    last_node_index = -1
    while True:
        max_node_id = max(nodes_to_explore, key = lambda node_ : node_.node_id).node_id
        curr_node : StrongBranchingNode = nodes_to_explore[node_index]
        if last_node_index != curr_node.node_id:
            nodes_to_explore[last_node_index].node_death = perf_counter_ns()
            last_node_index = curr_node.node_id
            print(f'Current node ID explored : {curr_node.node_id}')
        output = branch_and_price(settings_file, columns, distances, curr_node)
        if curr_node.status == STATUS_NAME[ERROR_CODE]:
            # Either an error has occured, or the model was infeasible
            node_index += 1
            curr_node.node_death = perf_counter_ns()
            if node_index == len(nodes_to_explore):
                return
        elif curr_node.status == STATUS_NAME[ADD_COLUMN]:
            assert output[0] == ADD_COLUMN
            new_column = output[1]
            nodes_to_explore[node_index].columns.append(tuple(new_column))
        elif curr_node.status == STATUS_NAME[OPT_INTSOL]:
            assert output[0] == OPT_INTSOL
            solution, objval = output[1], output[2]
            return solution, objval, curr_node.columns, nodes_to_explore
        elif curr_node.status == STATUS_NAME[NEW_BRANCH]:
            assert output[0] == NEW_BRANCH
            curr_node.left_child = max_node_id + 1
            curr_node.right_child = max_node_id + 2
            curr_node.node_death = perf_counter_ns()
            curr_node.branching_decision = output[-2]
            curr_node.branching_value = output[-1]
            left_cut_node = StrongBranchingNode(max_node_id + 1, curr_node.columns, curr_node.added_cuts + [output[1]], curr_node.node_id)
            right_cut_node = StrongBranchingNode(max_node_id + 2, curr_node.columns, curr_node.added_cuts + [output[2]], curr_node.node_id)
            nodes_to_explore.extend([left_cut_node, right_cut_node])
            node_index += 1
        print()

def main(instance_file : str):
    output = solver_branchandprice(instance_file)
    if output:
        solution, objval, columns, nodes_to_explore = output
        nb_cust, nb_supp = get_nb_cust(instance_file), get_nb_supp(instance_file)
        if solution:
            print(f'Optimal solution found - Cost : {objval}:')
            for philcolumn_ in columns:
                if hash(philcolumn_) in solution and solution[hash(philcolumn_)]:
                    print(f'\tColumn no. {hash(philcolumn_)} : {transform_column_to_arcs(philcolumn_, get_nb_cust(instance_file), get_nb_supp(instance_file))} : {solution[hash(philcolumn_)]} : {get_collected_supply(philcolumn_, nb_cust, nb_supp, get_supp_amount(instance_file))}')
        print()
        for node in nodes_to_explore:
            print(node)

if __name__ == '__main__':
    instance_file : str = input('Name of the instance file :')
    main(instance_file)
