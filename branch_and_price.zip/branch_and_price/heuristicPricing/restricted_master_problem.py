"""
    Solve the restricted master problem
"""
from column_init import compute_distances
from misc import *
from ortools.linear_solver import pywraplp

def get_nu_cr(cust_no : int, column : tuple[int]) -> int:
    '''
        Computes how many times customer [cust_no] is visited in [column]
    '''
    magic_cust_vect : list[int] = [0 for _ in column]
    # Update the magic vector
    magic_cust_vect[cust_no] = 1
    # Equivalent to return column[cust_no]
    return sum(x_*c_ for (x_, c_) in zip(magic_cust_vect, column))

def get_nu_sr(supp_no : int, column : tuple[int], nb_cust : int, nb_supp : int) -> int:
    '''
        Computes how many times customer [supp_no] is visited in [column]
    '''
    magic_supp_vect : list[int] = [0 for _ in column]
    # Update the magic vector
    # Update bloc C
    for c_ in range(nb_cust):
        magic_supp_vect[2*nb_cust + c_ * nb_supp + supp_no] = 1

    # Update bloc D
    for s1 in range(nb_supp):
        if s1 != supp_no:
            magic_supp_vect[nb_cust * (2 + nb_supp) + s1 * nb_supp + supp_no] = 1
    
    return sum(y_*s_ for (y_, s_) in zip(magic_supp_vect, column))

def get_nu_vector(column : tuple[int], nb_cust : int, nb_supp : int) -> tuple[int]:
    '''
        Computes how many times each location is visited in [column]
    '''
    nu_vector : list[int] = [0 for _ in range(nb_cust + nb_supp)]
    for c_ in range(nb_cust):
        nu_vector[c_] = get_nu_cr(c_, column)
    for s_ in range(nb_supp):
        nu_vector[nb_cust + s_] = get_nu_sr(s_, column, nb_cust, nb_supp)
    return tuple(nu_vector)

def solve_restricted_master_problem(
        input_file : str,
        columns : list[tuple[int]],
        cuts : list[tuple[int, str, int]]
        ) -> None | tuple[dict[int, float], dict[str, float], float]:
    nb_cust = get_nb_cust(input_file)
    nb_supp = get_nb_supp(input_file)
    supp_amount = get_supp_amount(input_file)
    min_collect = get_min_collect(input_file)

    solver : pywraplp.Solver = pywraplp.Solver.CreateSolver('GLOP')
    if not solver:
        print('Creation of the solver has failed.')
        return None

    hash_columns : list[int] = [hash(philcol_) for philcol_ in columns]
    theta : dict[int, pywraplp.Solver.NumVar] = {colh_ : solver.NumVar(0, solver.infinity(), f'theta_{colh_}') for colh_ in hash_columns}

    # Set partitionning constraints
    for c in range(nb_cust):
        # Associated dual variables : Alpha
        solver.Add(
            sum(get_nu_cr(c, col_) * theta[colh_] for col_, colh_ in zip(columns, hash_columns)) == 1,
            name = f'alpha_{c}')
    
    # Set packing constraints
    for s in range(nb_supp):
        # Associated dual variables : Beta
        solver.Add(
            sum(get_nu_sr(s, col_, nb_cust, nb_supp) * theta[colh_] for col_, colh_ in zip(columns, hash_columns)) <= 1,
            name = f'beta_{s}')

    # Set covering constraints
    solver.Add(
        sum(get_collected_supply(col_, nb_cust, nb_supp, supp_amount) * theta[hash(col_)] for col_ in columns) >= min_collect,
        name = 'delta'
    )

    # Cuts
    for cut_i, (colh, symb, bound) in enumerate(cuts):
        if symb == 'leq':
            # print(f'\t\tθ[{colh}] ≤ {bound}')
            solver.Add(theta[colh] <= bound, name = f'addcut_{cut_i}')
        elif symb == 'geq':
            # print(f'\t\tθ[{colh}] ≥ {bound}')
            solver.Add(theta[colh] >= bound, name = f'addcut_{cut_i}')
        else:
            print(f'Unknown symbol detected : {symb}')
    
    # Objective function
    cust_coords = get_cust_coords(input_file)
    supp_coords = get_supp_coords(input_file)
    coords = {loc_ : cust_coords[loc_] if loc_ in cust_coords else supp_coords[loc_] for loc_ in list(cust_coords.keys()) + list(supp_coords.keys())}
    distances = compute_distances(coords, cust_coords.keys(), supp_coords.keys())

    colcosts : dict[int, float] = {hash(col_) : get_alternative_cost(cust_coords, supp_coords, distances, col_) for col_ in columns}
    solver.Minimize(sum(colcosts[colh_] * theta[colh_] for colh_ in hash_columns))
    status = solver.Solve()
    if status == pywraplp.Solver.OPTIMAL:
        dual_values : dict[str, float] = {}
        for constraint in solver.constraints():
            cname_ = constraint.name()
            c_dv_ = constraint.dual_value()
            dual_values[cname_] = c_dv_
        solution = {colh_ : theta[colh_].solution_value() for colh_ in hash_columns}
        return solution, dual_values, solver.Objective().Value()
    else:
        return None
