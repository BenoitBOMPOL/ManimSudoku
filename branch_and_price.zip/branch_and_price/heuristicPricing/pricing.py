"""
    Pricing step :
        The pricing will find a route, that is not already described in the previous columns
        For now, the pricing will be done with several callback in order to avoid subtours

        May the odds be in my favour.
"""

from ortools.linear_solver import pywraplp
import networkx as nx
from misc import *

def build_model(
        settings_file : str,
        dual_values : dict[str, float],
        forbidden_routes : list[list[tuple[str, str]]],
        distances : dict[tuple[str, str], float],
        subtours : list[list[str]]
    ) -> tuple[pywraplp.Solver, dict] | None:
    """
        Creation of the Model
    """
    supp_amounts = get_supp_amount(settings_file)
    cust_demands = get_cust_demand(settings_file)
    truck_cap = get_truck_cap(settings_file)

    model : pywraplp.Solver = pywraplp.Solver.CreateSolver('SAT')
    if not model:
        return None
    
    # Creating the variables
    locations = ['depot'] + list(cust_demands.keys()) + list(supp_amounts.keys())

    x : dict[tuple[str, str], pywraplp.Solver.BoolVar] = {}
    for (u, v) in [(u_, v_) for u_ in locations for v_ in locations]:
        c1 = u == v
        c2 = (u != 'depot') and (v in cust_demands)
        c3 = (u == 'depot') and (v in supp_amounts)
        if not(c1 or c2 or c3):
            x[(u, v)] = model.BoolVar(f'x{u, v}')

    # Setting the constraints
    # Balance Equation
    for v in locations:
        model.Add(
            sum(x[(u_, v)] for u_ in locations if (u_, v) in x.keys()) == sum(x[(v, w_)] for w_ in locations if (v, w_) in x.keys()))
    
    # One customer only
    model.Add(sum(x[('depot', c_)] for c_ in cust_demands if ('depot', c_) in x.keys()) == 1)

    # Suppliers visited at most once
    for s in supp_amounts:
        model.Add(sum(x[(l_, s)] for l_ in locations if (l_, s) in x.keys()) <= 1)
        
    # Customer - Truck capacity
    for c in cust_demands:
        model.Add(x[('depot', c)] * cust_demands[c] <= truck_cap)
    
    # Suppliers - Truck capacity
    model.Add(sum(x[(l_, s_)] * supp_amounts[s_] for l_ in locations for s_ in supp_amounts if (l_, s_) in x.keys()) <= truck_cap)

    # Reject routes already in the columns
    for froute_ in forbidden_routes:
        model.Add(sum(x[(u_, v_)] for (u_, v_) in froute_) <= len(froute_) - 1)

    for stour_ in subtours:
        sec_cut = sum(x[(u_, v_)] for u_ in stour_ for v_ in stour_ if (u_, v_) in x.keys()) <= len(stour_) - 1
        model.Add(sec_cut)
        
    reduced_cost = sum(distances[(u_, v_)] * x[(u_, v_)] for (u_, v_) in x.keys())
    reduced_cost -= sum(dual_values[f'alpha_{int(c_[1:])}'] * x[('depot', c_)] for c_ in cust_demands if ('depot', c_) in x.keys())
    reduced_cost -= sum((dual_values[f'beta_{int(s_[1:])}'] + dual_values[f'delta'] * supp_amounts[s_]) * x[(u_, s_)] for s_ in supp_amounts for u_ in locations if (u_, s_) in x.keys())
    model.Minimize(reduced_cost)
    status = model.Solve()
    if status != pywraplp.Solver.OPTIMAL:
        return None
    return model, x

def get_new_subtours(
        settings_file : str,
        dual_values : dict[str, float],
        forbidden_routes : list[list[tuple[str, str]]],
        distances : dict[tuple[str, str], float],
        prev_subtours : list[list[str]]):
    supp_amount = get_supp_amount(settings_file)
    output = build_model(settings_file, dual_values, forbidden_routes, distances, prev_subtours)
    if output is None:
        return None
    model, arcs = output
    model.Solve()

    new_subtours : list[list[str]] = []
    edges = []
    for (s1, s2) in [(s1_, s2_) for s1_ in supp_amount for s2_ in supp_amount if (s1_, s2_) in arcs.keys()]:
        if arcs[(s1, s2)].solution_value():
            edges.append((s1, s2))
    supp_sdg = nx.DiGraph(edges)
    str_coco = list(nx.strongly_connected_components(supp_sdg))
    for subt in [subt_ for subt_ in str_coco if len(subt_) > 1]:
        new_subtours.append(subt)
    return new_subtours, model, arcs

def solve_pricing(
        settings_file : str,
        dual_values : dict[str, float],
        forbidden_routes : list[list[tuple[str, str]]],
        distances : dict[tuple[str, str], float]
    ):
    has_finished : bool = False
    subtours : list[list[str]] = []
    arcs : dict = {}
    model : pywraplp.Solver | None = None
    while not has_finished:
        output = get_new_subtours(settings_file, dual_values, forbidden_routes, distances, subtours)
        if output is None:
            return None
        else:
            next_subtours, model, arcs = output
            has_finished = len(next_subtours) == 0
            subtours.extend(next_subtours)
    
    if model is None:
        return None

    arcs_taken = [(u_, v_) for (u_, v_) in arcs.keys() if arcs[(u_, v_)].solution_value()]
    return model.Objective().Value(), arcs_taken

def solve_alternative_pricing(
        settings_file : str,
        dual_values : dict[str, float],
        forbidden_routes : list[list[tuple[str, str]]],
        distances : dict[tuple[str, str], float],
        max_nbsubtour_loops : int = 11):
    """
        If the pricing is stuck while finding subtours,
        the pricing stops with an infeasible column,
        a very high price (how to choose it ? | Maybe ~2*initialization value ?)
        Otherwise, the rest is the same than in the first pricing strategy
    """
    has_finished : bool = False
    subtours : list[list[str]] = []
    arcs : dict = {}
    model : pywraplp.Solver | None = None
    nb_iterations : int = 0
    while not has_finished:
        nb_iterations += 1
        if nb_iterations > max_nbsubtour_loops:
            # print('\t\tAn infeasible column will be added.')
            has_finished = True
        else:
            output = get_new_subtours(settings_file, dual_values, forbidden_routes, distances, subtours)
            if output is None:
                return None
            next_subtours, model, arcs = output
            has_finished = len(next_subtours) == 0
            subtours.extend(next_subtours)
    
    if model is None:
        return None

    arcs_taken = [(u_, v_) for (u_, v_) in arcs.keys() if arcs[(u_, v_)].solution_value()]
    return model.Objective().Value(), arcs_taken

def solve_heuristic_pricing(
        settings_file : str,
        dual_values : dict[str, float],
        forbidden_routes : list[list[tuple[str, str]]],
        distances : dict[tuple[str, str], float]):
    """
        The goal is to find heuristically a route with a negative reduced cost,
        If the heuristic does not find it, solve with the standard (exact) pricer 
    """
    reduced_dist : dict[tuple[str, str], float] = {}
    cuda : dict[str, float] = get_cust_demand(settings_file)
    suam : dict[str, float] = get_supp_amount(settings_file)

    # Construct the 'reduced' distance based on dual values 
    for (u, v) in distances.keys():
        c1 = (u == 'depot') and (v in cuda)
        c2 = v in suam
        if c1:
            reduced_dist[(u, v)] = distances[(u, v)] - dual_values[f'alpha_{int(v[1:])}']
        elif c2:
            reduced_dist[(u, v)] = distances[(u, v)] - dual_values[f'beta_{int(v[1:])}'] - suam[v] * dual_values[f'delta']
        else:
            reduced_dist[(u, v)] = distances[(u, v)]
    
    # Build the path
    closest_cust : str = min(list(cuda.keys()), key = lambda c_ : reduced_dist[('depot', c_)])
    heuristic_path : list[tuple[str, str]] = [('depot', closest_cust)]
    last_visited : str = heuristic_path[-1][-1]
    truck_cap : int = get_truck_cap(settings_file)
    truck_load : int = 0
    visited_suppliers : list[str] = []
    available_suppliers : list[str] = list(suam.keys())
    best_path : list[tuple[str, str]] = []
    best_redcost : float = float('inf')
    while available_suppliers:
        visited_suppliers = [v_ for (_, v_) in heuristic_path if v_ in suam.keys()]
        available_suppliers = [s_ for s_ in suam.keys() if s_ not in visited_suppliers if truck_load + suam[s_] <= truck_cap]
        if len(available_suppliers) == 0:
            heuristic_path.append((last_visited, 'depot'))
            red_heu_cost = sum(reduced_dist[p_] for p_ in heuristic_path)
            if sorted(heuristic_path) not in [sorted(p_) for p_ in forbidden_routes] and red_heu_cost < 0:
                if red_heu_cost < best_redcost:
                    best_redcost = red_heu_cost
                    best_path = heuristic_path
        else:
            curr_redcost : float = sum(reduced_dist[p_] for p_ in heuristic_path)
            if curr_redcost + reduced_dist[(last_visited, 'depot')] < 0:
                if sorted(heuristic_path + [(last_visited, 'depot')]) not in [sorted(p_) for p_ in forbidden_routes]:
                    if curr_redcost + reduced_dist[(last_visited, 'depot')] < best_redcost:
                        best_redcost = curr_redcost + reduced_dist[(last_visited, 'depot')]
                        best_path = heuristic_path + [(last_visited, 'depot')]
            next_supplier : str = min(available_suppliers, key = lambda s_ : reduced_dist[(last_visited, s_)])
            if curr_redcost + reduced_dist[(last_visited, next_supplier)] + reduced_dist[(next_supplier, 'depot')] < 0:
                if sorted(heuristic_path + [(last_visited, next_supplier), (next_supplier, 'depot')]) not in [sorted(p_) for p_ in forbidden_routes]:
                    if curr_redcost + reduced_dist[(last_visited, next_supplier)] + reduced_dist[(next_supplier, 'depot')] < best_redcost:
                        best_redcost = curr_redcost + reduced_dist[(last_visited, next_supplier)] + reduced_dist[(next_supplier, 'depot')]
                        best_path = heuristic_path + [(last_visited, next_supplier), (next_supplier, 'depot')]
            heuristic_path.append((last_visited, next_supplier))
            last_visited = next_supplier
    if best_redcost < 0 and sorted(best_path) not in [sorted(p_) for p_ in forbidden_routes]:
        # print(f'Heuristic pricing has succeeded, with {best_path = } | {best_redcost = }.')
        return best_redcost, best_path
    # print(f'Heuristic pricing has failed, with {best_path = } | {best_redcost = }.')
    return solve_pricing(settings_file, dual_values, forbidden_routes, distances)

def solve_heuristic_pricing_v2(
        settings_file : str,
        dual_values : dict[str, float],
        forbidden_routes : list[list[tuple[str, str]]],
        distances : dict[tuple[str, str], float]):
    """
        The goal is to find heuristically a route with a negative reduced cost,
        If the heuristic does not find it, solve with the standard (exact) pricer 
    """
    reduced_dist : dict[tuple[str, str], float] = {}
    cuda : dict[str, float] = get_cust_demand(settings_file)
    suam : dict[str, float] = get_supp_amount(settings_file)

    # Construct the 'reduced' distance based on dual values 
    for (u, v) in distances.keys():
        c1 = (u == 'depot') and (v in cuda)
        c2 = v in suam
        if c1:
            reduced_dist[(u, v)] = distances[(u, v)] - dual_values[f'alpha_{int(v[1:])}']
        elif c2:
            reduced_dist[(u, v)] = distances[(u, v)] - dual_values[f'beta_{int(v[1:])}'] - suam[v] * dual_values[f'delta']
        else:
            reduced_dist[(u, v)] = distances[(u, v)]
    
    best_path : list[tuple[str, str]] = []
    best_redcost : float = float('inf')
    # Build the path
    for closest_cust in sorted(list(cuda.keys()), key = lambda c_ : reduced_dist[('depot', c_)]):
        heuristic_path : list[tuple[str, str]] = [('depot', closest_cust)]
        last_visited : str = heuristic_path[-1][-1]
        truck_cap : int = get_truck_cap(settings_file)
        truck_load : int = 0
        visited_suppliers : list[str] = []
        available_suppliers : list[str] = list(suam.keys())
        while available_suppliers:
            visited_suppliers = [v_ for (_, v_) in heuristic_path if v_ in suam.keys()]
            available_suppliers = [s_ for s_ in suam.keys() if s_ not in visited_suppliers if truck_load + suam[s_] <= truck_cap]
            if len(available_suppliers) == 0:
                heuristic_path.append((last_visited, 'depot'))
                red_heu_cost = sum(reduced_dist[p_] for p_ in heuristic_path)
                if sorted(heuristic_path) not in [sorted(p_) for p_ in forbidden_routes] and red_heu_cost < 0:
                    if red_heu_cost < best_redcost:
                        best_redcost = red_heu_cost
                        best_path = heuristic_path
            else:
                curr_redcost : float = sum(reduced_dist[p_] for p_ in heuristic_path)
                if curr_redcost + reduced_dist[(last_visited, 'depot')] < 0:
                    if sorted(heuristic_path + [(last_visited, 'depot')]) not in [sorted(p_) for p_ in forbidden_routes]:
                        if curr_redcost + reduced_dist[(last_visited, 'depot')] < best_redcost:
                            best_redcost = curr_redcost + reduced_dist[(last_visited, 'depot')]
                            best_path = heuristic_path + [(last_visited, 'depot')]
                next_supplier : str = min(available_suppliers, key = lambda s_ : reduced_dist[(last_visited, s_)])
                if curr_redcost + reduced_dist[(last_visited, next_supplier)] + reduced_dist[(next_supplier, 'depot')] < 0:
                    if sorted(heuristic_path + [(last_visited, next_supplier), (next_supplier, 'depot')]) not in [sorted(p_) for p_ in forbidden_routes]:
                        if curr_redcost + reduced_dist[(last_visited, next_supplier)] + reduced_dist[(next_supplier, 'depot')] < best_redcost:
                            best_redcost = curr_redcost + reduced_dist[(last_visited, next_supplier)] + reduced_dist[(next_supplier, 'depot')]
                            best_path = heuristic_path + [(last_visited, next_supplier), (next_supplier, 'depot')]
                heuristic_path.append((last_visited, next_supplier))
                last_visited = next_supplier
    if best_redcost < 0 and sorted(best_path) not in [sorted(p_) for p_ in forbidden_routes]:
        # print('\tHeuristic Pricing has succeeded')
        return best_redcost, best_path
    # print('\tHeuristic Pricing has failed')
    return solve_pricing(settings_file, dual_values, forbidden_routes, distances)

def solve_heuristic_pricing_v3(
        settings_file : str,
        dual_values : dict[str, float],
        forbidden_routes : list[list[tuple[str, str]]],
        distances : dict[tuple[str, str], float]):
    
    sorted_forbidden_routes = [sorted(froute_) for froute_ in forbidden_routes]

    reduced_dist : dict[tuple[str, str], float] = {}
    cuda : dict[str, float] = get_cust_demand(settings_file)
    suam : dict[str, float] = get_supp_amount(settings_file)
    truck_cap : int = get_truck_cap(settings_file)

    # Construct the 'reduced' distance based on dual values 
    for (u, v) in distances.keys():
        c1 = (u == 'depot') and (v in cuda)
        c2 = v in suam
        if c1:
            reduced_dist[(u, v)] = distances[(u, v)] - dual_values[f'alpha_{int(v[1:])}']
        elif c2:
            reduced_dist[(u, v)] = distances[(u, v)] - dual_values[f'beta_{int(v[1:])}'] - suam[v] * dual_values[f'delta']
        else:
            reduced_dist[(u, v)] = distances[(u, v)]
    
    # Finding an arc (c, l) that has the minimum reduced cost
    init_path : tuple[str, str] = min([p_ for p_ in distances.keys() if p_[0] in cuda.keys()], key = reduced_dist.get)
    path : list[tuple[str, str]] = [('depot', init_path[0]), init_path]
    if init_path[1] == 'depot':
        # If the route is under the following form (0 -> c -> 0)
        if sum(reduced_dist[a_] for a_ in path) >= 0 or sorted(path) in sorted_forbidden_routes:
            # If reduced cost >= 0
            # or route already in the columns
            # Call the standard pricer
            return solve_pricing(settings_file, dual_values, forbidden_routes, distances)
        # Otherwise route can be added.
        return sum(reduced_dist[a_] for a_ in path), path
    curr_load : float = suam[path[-1][-1]]
    while True:
        # I check if the route can be added.
        last_visited = path[-1][-1]
        complete_route = path + [(last_visited, 'depot')]
        if sum(reduced_dist[a_] for a_ in complete_route) < 0 and sorted(complete_route) not in sorted_forbidden_routes:
            # If it can, I stop here (no need to go further)
            return sum(reduced_dist[a_] for a_ in complete_route), complete_route
        # I check if there are suppliers available (not yet added AND that satisfy truck capacity constraint)
        available_supp : list[str] = [s_ for s_ in suam.keys() if s_ not in [p_[1] for p_ in path] and curr_load + suam[s_] <= truck_cap]
        if len(available_supp) == 0:
            # If there are no suppliers, I already know that the current complete route won't work
            # I call the standard pricer.
            return solve_pricing(settings_file, dual_values, forbidden_routes, distances)
        # I find the next relevant locations
        available_locations = available_supp + ['depot']
        next_visited = min(available_locations, key = lambda l_ : reduced_dist[(last_visited, l_)])
        if next_visited == 'depot':
            complete_route = path + [(last_visited, 'depot')]
            if sum(reduced_dist[a_] for a_ in complete_route) < 0 and sorted(complete_route) not in sorted_forbidden_routes:
                return sum(reduced_dist[a_] for a_ in complete_route), complete_route
            return solve_pricing(settings_file, dual_values, forbidden_routes, distances)
        path.append((last_visited, next_visited))
    