class StrongBranchingNode:
    def __init__(self,
                 node_id : int,
                 columns : list[tuple[int]],
                 added_cuts : list[tuple[int, str, int]],
                 parent_id : int = -1) -> None:
        """
            A node is :
                A unique [node_id]
                A set of columns
                A list of cuts added to the RMP
                The id of the parent
                The value of the linear relaxation of the RMP
                The status [OPTIMAL / INFEASIBLE / ...]
        """
        self.node_id : int = node_id
        self.columns : list[tuple[int]] = columns
        self.added_cuts : list[tuple[int, str, int]] = added_cuts
        self.parent_id : int = parent_id
        self.lr_rmp : float = float('inf')
        self.status : str|None = None
        self.nb_calls_pr : int = 0
        self.branching_decision : int|None = None
        self.branching_value : float|None = None
        self.left_child : int = -1
        self.right_child : int = -1
        self.node_death : int = -1
        # Time at which this node is 'left for dead, either because opt/branch/etc'
    
    def __str__(self) -> str:
        sbn_str : str = f'*** [Node {self.node_id}] [Parent : {self.parent_id}] ***'
        sbn_str += f'\n\tNumber of calls to the pricer in that node : {self.nb_calls_pr}'
        sbn_str += f'\n\tValue of the LR of the RMP : {self.lr_rmp}'
        sbn_str += f'\n\tStatus : {self.status}'
        if self.status == 'Branching':
            sbn_str += f'\n\t\tBranching decision on θ[{self.branching_decision}] (= {self.branching_value})'
        sbn_str += '\n\tChildren :'
        sbn_str += f'\n\t\tLeft child : {self.left_child}'
        sbn_str += f'\n\t\tRight child : {self.right_child}'
        sbn_str += f'\n\tNode death @{self.node_death}'
        return sbn_str
