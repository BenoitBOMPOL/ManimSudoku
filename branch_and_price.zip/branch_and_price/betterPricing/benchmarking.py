"""
    Time benchmarking
"""
import os
from time import perf_counter_ns
import pandas as pd
from branchprice import solver_branchandprice
from IPython.display import display

FOLDER_NAME : str = 'C:/Users/BompolB/Desktop/SWI_TruckOptimization_CB_2024/src/branch_and_price/vrp_xlsx_instances'

def get_all_instance_names(folder_name : str) -> list[str]:
    return sorted(set([f_ for f_ in os.listdir(folder_name) if os.path.isfile(f'{folder_name}/{f_}')])) 

def get_perf_time(instance_name : str) -> float:
    """
        Returns the time required by the solver in order to solve the instance
    """
    t1 = perf_counter_ns()
    t2 = float('inf')
    output = solver_branchandprice(instance_name)
    if output:
        t2 = perf_counter_ns()
    delta = t2 - t1
    return delta * 1E-9

def run_instance(instance_filename : str) -> list[float]:
    '''
        Runs the [instance_filename] on both
            - OR-Tools as a reference
            - BranchPrice implementation
        
        Returns : 
            [time_bp, opt_bp, branchs, calls_to_pricer]
    '''
    t1_bp = perf_counter_ns()
    t2_bp = float('inf')
    bp_output = solver_branchandprice(instance_filename)
    if bp_output:
        t2_bp = perf_counter_ns()

    results : list[float] = [(t2_bp - t1_bp) * 1E-9, None, None, None]
    if bp_output:
        results[1] = bp_output[1]
        created_nodes = bp_output[3]
        results[-2] = sum([int(node_.status == 'Branching') for node_ in created_nodes])
        results[-1] = sum([node_.nb_calls_pr for node_ in created_nodes])
    return results

def main(folder_name : str, output_filename : str):
    benchmark_df : pd.DataFrame = pd.DataFrame(columns = ['instance_name', 'time_bp', 'opt_bp', 'branchs', 'calls_to_pricing'])
    for instance_name in get_all_instance_names(folder_name):
        print(f'Instance {instance_name}')
        instance_filename = folder_name + '/' + instance_name
        new_row = [instance_name] + run_instance(instance_filename)
        benchmark_df.loc[len(benchmark_df.index)] = new_row
        display(benchmark_df)
        print()
        benchmark_df.to_excel(output_filename, index=False)

if __name__ == '__main__':
    instance_subset = input('Set to cover in the benchmark :')
    main(FOLDER_NAME + f'/{instance_subset}', f'benchmark_set_{instance_subset}.xlsx')
