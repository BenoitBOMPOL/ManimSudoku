"""
    Pricing step :
        The pricing will find a route, that is not already described in the previous columns
        For now, the pricing will be done with several callback in order to avoid subtours

        May the odds be in my favour.
"""

from ortools.linear_solver import pywraplp
import networkx as nx
from misc import *

def build_model(
        settings_file : str,
        dual_values : dict[str, float],
        forbidden_routes : list[list[tuple[str, str]]],
        distances : dict[tuple[str, str], float],
        subtours : list[list[str]]
    ) -> tuple[pywraplp.Solver, dict] | None:
    """
        Creation of the Model
    """
    supp_amounts = get_supp_amount(settings_file)
    cust_demands = get_cust_demand(settings_file)

    model : pywraplp.Solver = pywraplp.Solver.CreateSolver('SAT')
    if not model:
        return None
    
    # Creating the variables
    locations = ['depot'] + list(cust_demands.keys()) + list(supp_amounts.keys())

    x : dict[tuple[str, str], pywraplp.Solver.BoolVar] = {}
    for (u, v) in [(u_, v_) for u_ in locations for v_ in locations]:
        c1 = u == v
        c2 = (u != 'depot') and (v in cust_demands)
        c3 = (u == 'depot') and (v in supp_amounts)
        if not(c1 or c2 or c3):
            x[(u, v)] = model.BoolVar(f'x{u, v}')

    # Setting the constraints
    # Balance Equation
    for v in locations:
        model.Add(
            sum(x[(u_, v)] for u_ in locations if (u_, v) in x.keys()) == sum(x[(v, w_)] for w_ in locations if (v, w_) in x.keys()))
    
    # One customer only
    model.Add(sum(x[('depot', c_)] for c_ in cust_demands if ('depot', c_) in x.keys()) == 1)

    # Suppliers visited at most once
    for s in supp_amounts:
        model.Add(sum(x[(l_, s)] for l_ in locations if (l_, s) in x.keys()) <= 1)

    # Reject routes already in the columns
    for froute_ in forbidden_routes:
        model.Add(sum(x[(u_, v_)] for (u_, v_) in froute_) <= len(froute_) - 1)

    for stour_ in subtours:
        sec_cut = sum(x[(u_, v_)] for u_ in stour_ for v_ in stour_ if (u_, v_) in x.keys()) <= len(stour_) - 1
        model.Add(sec_cut)
        
    reduced_cost = sum(distances[(u_, v_)] * x[(u_, v_)] for (u_, v_) in x.keys())
    reduced_cost -= sum(dual_values[f'alpha_{int(c_[1:])}'] * x[('depot', c_)] for c_ in cust_demands if ('depot', c_) in x.keys())
    reduced_cost -= sum((dual_values[f'beta_{int(s_[1:])}'] + dual_values['epsilon'] * supp_amounts[s_]) * x[(u_, s_)] for s_ in supp_amounts for u_ in locations if (u_, s_) in x.keys())
    model.Minimize(reduced_cost)
    status = model.Solve()
    if status != pywraplp.Solver.OPTIMAL:
        return None
    return model, x

def get_new_subtours(
        settings_file : str,
        dual_values : dict[str, float],
        forbidden_routes : list[list[tuple[str, str]]],
        distances : dict[tuple[str, str], float],
        prev_subtours : list[list[str]]):
    supp_amount = get_supp_amount(settings_file)
    output = build_model(settings_file, dual_values, forbidden_routes, distances, prev_subtours)
    if output is None:
        return None
    model, arcs = output
    model.Solve()

    new_subtours : list[list[str]] = []
    edges = []
    for (s1, s2) in [(s1_, s2_) for s1_ in supp_amount for s2_ in supp_amount if (s1_, s2_) in arcs.keys()]:
        if arcs[(s1, s2)].solution_value():
            edges.append((s1, s2))
    supp_sdg = nx.DiGraph(edges)
    str_coco = list(nx.strongly_connected_components(supp_sdg))
    for subt in [subt_ for subt_ in str_coco if len(subt_) > 1]:
        new_subtours.append(subt)
    return new_subtours, model, arcs

def solve_pricing(
        settings_file : str,
        dual_values : dict[str, float],
        forbidden_routes : list[list[tuple[str, str]]],
        distances : dict[tuple[str, str], float]
    ):
    has_finished : bool = False
    subtours : list[list[str]] = []
    arcs : dict = {}
    model : pywraplp.Solver | None = None
    while not has_finished:
        output = get_new_subtours(settings_file, dual_values, forbidden_routes, distances, subtours)
        if output is None:
            return None
        else:
            next_subtours, model, arcs = output
            has_finished = len(next_subtours) == 0
            subtours.extend(next_subtours)
    
    if model is None:
        return None

    arcs_taken = [(u_, v_) for (u_, v_) in arcs.keys() if arcs[(u_, v_)].solution_value()]
    return model.Objective().Value(), arcs_taken

def solve_alternative_pricing(
        settings_file : str,
        dual_values : dict[str, float],
        forbidden_routes : list[list[tuple[str, str]]],
        distances : dict[tuple[str, str], float],
        max_nbsubtour_loops : int = 11):
    """
        If the pricing is stuck while finding subtours,
        the pricing stops with an infeasible column,
        a very high price (how to choose it ? | Maybe ~2*initialization value ?)
        Otherwise, the rest is the same than in the first pricing strategy
    """
    has_finished : bool = False
    subtours : list[list[str]] = []
    arcs : dict = {}
    model : pywraplp.Solver | None = None
    nb_iterations : int = 0
    while not has_finished:
        nb_iterations += 1
        if nb_iterations > max_nbsubtour_loops:
            # print('\t\tAn infeasible column will be added.')
            has_finished = True
        else:
            output = get_new_subtours(settings_file, dual_values, forbidden_routes, distances, subtours)
            if output is None:
                return None
            next_subtours, model, arcs = output
            has_finished = len(next_subtours) == 0
            subtours.extend(next_subtours)
    
    if model is None:
        return None

    arcs_taken = [(u_, v_) for (u_, v_) in arcs.keys() if arcs[(u_, v_)].solution_value()]
    return model.Objective().Value(), arcs_taken
