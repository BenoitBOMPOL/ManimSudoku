'''
    Useful / Misc function for the Branch and Price
'''

import networkx as nx
import pandas as pd
from math import log10

def get_nb_cust(input_filename : str) -> int:
    '''
        Returns the number of customers in the instance
    '''
    custdf : pd.DataFrame = pd.read_excel(input_filename, sheet_name  = 'customers')
    return len(custdf)

def get_nb_supp(input_filename : str) -> int:
    '''
        Returns the number of suppliers in the instance
    '''
    suppdf : pd.DataFrame = pd.read_excel(input_filename, sheet_name  = 'suppliers')
    return len(suppdf)

def get_truck_cap(input_filename : str) -> int:
    '''
        Return the capacity of a truck
    '''
    paramdf : pd.DataFrame = pd.read_excel(input_filename, sheet_name = 'parameters')
    return paramdf['truck_cap'].to_list()[0]

def get_cust_demand(input_filename : str) -> dict[str, float]:
    '''
        Return as a dict the demands of each customer
    '''
    custdf : pd.DataFrame = pd.read_excel(input_filename, sheet_name = 'customers')
    return {row['custNo'] : row['demand'] for _, row in custdf.iterrows()}

def get_supp_amount(input_filename : str) -> dict[str, float]:
    '''
        Return as a dict the amount of supply available
    '''
    suppdf : pd.DataFrame = pd.read_excel(input_filename, sheet_name = 'suppliers')
    return {row['suppNo'] : row['supply'] for _, row in suppdf.iterrows()}

def get_min_collect(input_filename : str) -> float:
    '''
        Returns the minimum amount there is to collect
    '''
    paramdf : pd.DataFrame = pd.read_excel(input_filename, sheet_name = 'parameters')
    return paramdf['min_collect'].to_list()[0]

def get_cust_coords(input_filename : str) -> dict[str, tuple[float, float]]:
    '''
        Returns x/y coordinates of all customers
    '''
    custdf : pd.DataFrame = pd.read_excel(input_filename, sheet_name = 'customers')
    cust_coords : dict[str, tuple[float, float]] = {}
    for _, row in custdf.iterrows():
        cust_coords[row['custNo']] = (row['locX'], row['locY'])
    return cust_coords

def get_supp_coords(input_filename : str) -> dict[str, tuple[float, float]]:
    '''
        Returns x/y coordinates of all suppliers
    '''
    suppdf : pd.DataFrame = pd.read_excel(input_filename, sheet_name = 'suppliers')
    supp_coords : dict[str, tuple[float, float]] = {}
    for _, row in suppdf.iterrows():
        supp_coords[row['suppNo']] = (row['locX'], row['locY'])
    return supp_coords

"""
    A column depicts all allowed arcs in a route :
            From the depot to a customer            |C| variables
        X[S, c] (0 ... |C| - 1)

            From a customer back to the depot       |C| variables
        X[c, S] (C ... 2|C| - 1)

            From a customer to a supplier           |C| * |S| variables
        X[c, s] (2|C| ...  |C|(2 + |S|) - 1)

            From a supplier to a supplier           |S| ** 2 variables
        X[s, s'] |C|(2 + |S|) ... |C| (2 + |S|) + |S|^2 - 1

            From a supplier back to the depot       |S| variables
        X[s, S] |C| (2 + |S|) + |S^2| ... |C| (2 + |S|) + |S^2| + |S| - 1
"""

def transform_column_to_arcs(column : tuple[int], nb_cust : int, nb_supp : int) -> list[tuple[str, str]]:
    arcs : list[tuple[str, str]] = []
    # Bloc A
    for ia_ in range(nb_cust):
        if column[ia_]:
            custname_ = f'c{str(ia_).zfill(int(log10(nb_cust - 1)) + 1)}'
            arcs.append(('depot', custname_))
    # Bloc B
    for ib_ in range(nb_cust, 2 * nb_cust):
        if column[ib_]:
            custname_ = f'c{str(ib_ - nb_cust).zfill(int(log10(nb_cust - 1)) + 1)}'
            arcs.append((custname_, 'depot'))
    # Bloc C
    for c1 in range(nb_cust):
        for s1 in range(nb_supp):
            if column[2*nb_cust + nb_supp * c1 + s1]:
                custname_ = f'c{str(c1).zfill(int(log10(nb_cust - 1)) + 1)}'
                suppname_ = f's{str(s1).zfill(int(log10(nb_supp - 1)) + 1)}'
                arcs.append((custname_, suppname_))
    # Bloc D
    for s2 in range(nb_supp):
        for s3 in range(nb_supp):
            if column[nb_cust*(2 + nb_supp) + nb_supp * s2 + s3]:
                s2name_ = f's{str(s2).zfill(int(log10(nb_supp - 1)) + 1)}'
                s3name_ = f's{str(s3).zfill(int(log10(nb_supp - 1)) + 1)}'
                arcs.append((s2name_, s3name_))
    # Bloc E
    for s4 in range(nb_supp):
        if column[nb_cust*(2 + nb_supp) + nb_supp**2 + s4]:
            s4name_ = f's{str(s4).zfill(int(log10(nb_supp - 1)) + 1)}'
            arcs.append((s4name_, 'depot'))
    return arcs

def get_collected_supply(column : tuple[int], nb_cust : int, nb_supp : int, supp_amount : dict[str, float]) -> float:
    '''
        Computes the overall amount of supply collected in a single column
    '''
    collected_amount : float = 0.0
    sorted_suppnames : list[str] = sorted(list(supp_amount.keys()))
    # Collected from a customer to a supplier
    for c1_ in range(nb_cust):
        for s1_ in range(nb_supp):
            if column[2*nb_cust + c1_ * nb_supp + s1_]:
                suppname_ = sorted_suppnames[s1_]
                collected_amount += supp_amount[suppname_]
    
    # Collected from a supplier to a supplier
    for s2_ in range(nb_supp):
        for s3_ in range(nb_supp):
            if column[nb_cust * (2 + nb_supp) + nb_supp * s2_ + s3_]:
                suppname_ = sorted_suppnames[s3_]
                collected_amount += supp_amount[suppname_]
    return collected_amount

def get_cost(
        cust_coords : dict[str, tuple[float, float]],
        supp_coords : dict[str, tuple[float, float]],
        distances : dict[tuple[str, str], float],
        column : tuple[int, ...]) -> float:
    '''
        Computes the cost associated with a column
    '''
    distance = 0.0
    # depot -> customer | customer -> depot
    for c_, custname_ in enumerate(sorted(cust_coords.keys())):
        if column[c_]:
            distance += distances[('depot', custname_)]
        if column[c_ + len(cust_coords)]:
            distance += distances[('depot', custname_)]

    # customer -> supplier
    nb_cust = len(cust_coords)
    nb_supp = len(supp_coords)
    for c_, custname_ in enumerate(sorted(cust_coords.keys())):
        for s_, suppname_ in enumerate(sorted(supp_coords.keys())):
            if column[2*nb_cust + nb_supp * c_ + s_]:
                distance += distances[(custname_, suppname_)]

    # supplier -> supplier
    for s1_, s1name_ in enumerate(sorted(supp_coords.keys())):
        for s2_, s2name_ in enumerate(sorted(supp_coords.keys())):
            if column[nb_cust*(2 + nb_supp) + nb_supp * s1_ + s2_]:
                distance += distances[(s1name_, s2name_)]

    # supplier -> depot
    for s_, sname_ in enumerate(sorted(supp_coords.keys())):
        if column[nb_cust*(2 + nb_supp) + nb_supp**2 + s_]:
            distance += distances[(sname_, 'depot')]
    return distance

def has_subtours(
        column : tuple[int],
        nb_supp : int,
        nb_cust : int) -> bool:
    '''
        Input :
            - column : The column it is required to check
            - nb_cust, nb_supp are here to access more easily the indices

        Output :
            - True / False whether column is feasible or not

        To Check :
            For now, I'll only check for subtours, as it 
    '''
    edges : list[tuple[int, int]] = []
    for (s1, s2) in [(s1_, s2_) for s1_ in range(nb_supp) for s2_ in range(nb_supp)]:
        if column[nb_cust * (2 + nb_supp) + nb_supp * s1 + s2]:
            edges.append((s1, s2))
    supp_directedgraph : nx.DiGraph = nx.DiGraph(edges)
    pot_str_conn_comp : list = nx.strongly_connected_components(supp_directedgraph)
    strongly_con_comp : list = [potsub_ for potsub_ in pot_str_conn_comp if len(potsub_) > 1]
    if len(strongly_con_comp) > 0:
        return True
    return False

def get_alternative_cost(
        cust_coords : dict[str, tuple[float, float]],
        supp_coords : dict[str, tuple[float, float]],
        distances : dict[tuple[str, str], float],
        column : tuple[int, ...]) -> float:
    nb_cust : int = len(cust_coords)
    nb_supp : int = len(supp_coords)
    if has_subtours(column, nb_supp, nb_cust):
        return 1.05 * get_cost(cust_coords, supp_coords, distances, column)
    return get_cost(cust_coords, supp_coords, distances, column)
