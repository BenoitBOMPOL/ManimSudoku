"""
    Initialisation of the problem

    Complete algorithm :
        Step 0 : Create an empty list of columns : list[list[int]]

        Step 1 : [Bin Packing]
            Solve the packing problem, in order to ensure the feasibility
            Outputs : x[s, t], y[t]
    
        Step 2 : [Nearest Neighbor] | [>= 1 supplier]
            For each t such that y[t] = 1
                Building a path from the depot,
                containing all suppliers [s] such that x[s, t] = 1

                Add the closest available customer to the path
                Create the column (beware of the order of arcs)
                add it to the set of columns
        
        Step 3 : [Nearest Neighbor] | [0 supplier]
            For each t such that y[t] = 0
                Find the closest available customer
                Create the column, add it to the set of columns
"""

from math import sqrt
from ortools.linear_solver import pywraplp
from copy import deepcopy
from misc import *

DEPOT_NAME : str = 'depot'

def solve_binpacking(nb_trucks : int, truck_cap : int, supp_amounts : dict[str, int], min_collect : int) -> tuple[dict[int, int], dict[int, int]] | None:
    """
        Step 1 : [Bin Packing]
            Solve the packing problem, in order to ensure the feasibility
            Outputs : x[s, t], y[t]
    """
    trucks = range(nb_trucks)

    solver : pywraplp.Solver = pywraplp.Solver.CreateSolver('SAT')
    if not solver:
        return None
    
    x : dict[tuple[int, int], pywraplp.Solver.BoolVar]
    x = {(s_, t_) : solver.BoolVar(f'x[s = {s_}, t = {t_}]') for s_ in supp_amounts for t_ in trucks}

    y : dict[int, pywraplp.Solver.BoolVar]
    y = {t_ : solver.BoolVar(f'y[t = {t_}]') for t_ in trucks}

    # y[t] >= x[s, t]
    for (s, t) in [(s_, t_) for s_ in supp_amounts for t_ in trucks]:
        solver.Add(y[t] >= x[(s, t)])

    # sum(x[s, t], t in T) <= 1
    for s in supp_amounts:
        solver.Add(sum(x[(s, t_)] for t_ in trucks) <= 1)
    
    # sum(p[s] * x[s, t], t in T, s in S) >= m
    solver.Add(sum(supp_amounts[s_] * x[(s_, t_)] for s_ in supp_amounts for t_ in trucks) >= min_collect)

    # sum(p[s] * x[s, t], s in S) <= q
    for t in trucks:
        solver.Add(sum(supp_amounts[s_] * x[(s_, t)] for s_ in supp_amounts) <= truck_cap)

    # y[t] <= sum(x[s_, t], s_ in S)
    for t in trucks:
        solver.Add(y[t] <= sum(x[(s_, t)] for s_ in supp_amounts))

    #solver.EnableOutput()
    # min sum(y[t], t in T)
    solver.Minimize(sum(y[t_] for t_ in trucks))
    status = solver.Solve()
    if status == pywraplp.Solver.OPTIMAL:
        x_sol = {(s_, t_) : x[(s_, t_)].solution_value() for (s_, t_) in x.keys()}
        y_sol = {t_ : y[t_].solution_value() for t_ in y.keys()}
        return x_sol, y_sol
    return None

def compute_distances(coords : dict[str, tuple[int, int]], cust_names : list[str], supp_names : list[str]) -> dict[tuple[str, str], float]:
    distances : dict[tuple[str, str], float] = {}
    for c in cust_names:
        x_c, y_c = coords[c]
        dist_dc = round(sqrt(x_c**2 + y_c**2), 3)
        # Type 1 and 2
        distances[(DEPOT_NAME, c)] = dist_dc
        distances[(c, DEPOT_NAME)] = dist_dc
        # Type 3
        for s in supp_names:
            x_s, y_s = coords[s]
            dist_cs = round(sqrt((x_c - x_s)**2 + (y_c - y_s)**2), 3)
            distances[(c, s)] = dist_cs
    for s in supp_names:
        x_s, y_s = coords[s]
        dist_sd = round(sqrt(x_s**2 + y_s**2), 3)
        distances[(s, DEPOT_NAME)] = dist_sd
        for s1 in [s_ for s_ in supp_names if s != s_]:
            x_s1, y_s1 = coords[s1]
            dist_ss1 = round(sqrt((x_s - x_s1)**2 + (y_s - y_s1)**2), 3)
            distances[(s, s1)] = dist_ss1
    return distances

def nn_supp(to_visit : list[str], distances : dict[tuple[str, str], float]) -> list[tuple[str, str]]:
    """
        Constructs, under the 'Nearest Neighbour' heuristic, a path
            to_visit : list[str]
                List of all suppliers that must be visited.
                Its length is assumed > 0
            
                distances : dict of all distances
    """
    last_dest : str = DEPOT_NAME
    path : list[tuple[str, str]] = []
    while to_visit:
        best_dist : float = float('inf')
        best_arc : str = None
        for s in to_visit:
            if (s, last_dest) in distances.keys() and distances[(s, last_dest)] < best_dist:
                best_dist = distances[(s, last_dest)]
                best_arc = (s, last_dest)
        if best_arc is None:
            return path
        to_visit = [s_ for s_ in to_visit if s_ != best_arc[1]]
        path = [best_arc] + path
        last_dest = best_arc[0]
    return path

def create_column(column_size : int, path : list[tuple[str, str]], nb_cust : int, nb_supp : int) -> tuple[int]:
    column : list[int] = [0 for _ in range(column_size)]
    for (u, v) in path:
        if u == DEPOT_NAME:
            c_no = int(v[1:])
            column[c_no] = 1
        elif u[0] == 'c' and v == DEPOT_NAME:
            c_no = int(u[1:])
            column[nb_cust + c_no] = 1
        elif u[0] == 'c':
            c_no = int(u[1:])
            s_no = int(v[1:])
            column[2*nb_cust + nb_supp * c_no + s_no] = 1
        elif u[0] == 's' and v[0] == 's':
            s1_no = int(u[1:])
            s2_no = int(v[1:])
            column[nb_cust * (2 + nb_supp) + nb_supp * s1_no + s2_no] = 1
        elif u[0] == 's':
            s_no = int(u[1:])
            column[nb_cust * (2 + nb_supp) + nb_supp * nb_supp + s_no] = 1
    return column

def generate_first_columns(
        distances : dict[tuple[str, str], float],
        cust_names : list[str],
        truck_cap : int,
        supp_amounts : dict[str, int],
        min_collect : int) -> list[tuple[int]] | None:
    nb_trucks = len(cust_names)
    trucks = range(nb_trucks)

    nb_cust = nb_trucks
    nb_supp = len(supp_amounts)
    column_size = 2 * nb_cust + (nb_cust + 1) * nb_supp + (nb_supp * nb_supp)
    columns : list[tuple[int]] = []

    # Step 1 : Solve the packing problem
    packing_output = solve_binpacking(nb_trucks, truck_cap, supp_amounts, min_collect)
    if packing_output is None:
        print('Packing problem has failed.')
        return None
    x_sol, y_sol = packing_output

    remaining_customers : list[str] = deepcopy(cust_names)
    # Step 2 : Use nearest neighbour on t such that y_sol[t] = 1
    for t in [t_ for t_ in trucks if y_sol[t_]]:
        visited_suppliers = [s_ for s_ in supp_amounts if x_sol[(s_, t)]]
        supplier_path = nn_supp(visited_suppliers, distances)
        f_supp_vis = supplier_path[0][0]
        dist_to_available_customers = {c_ : distances[(c_, f_supp_vis)] for c_ in remaining_customers}
        closest_cust = min(dist_to_available_customers, key = dist_to_available_customers.get)
        remaining_customers = [c_ for c_ in remaining_customers if c_ != closest_cust]
        path = [(DEPOT_NAME, closest_cust), (closest_cust, f_supp_vis)] + supplier_path
        column = create_column(column_size, path, nb_cust, nb_supp)
        columns.append(tuple(column))

    for t in [t_ for t_ in trucks if not y_sol[t_]]:
        path = [(DEPOT_NAME, remaining_customers[0]), (remaining_customers[0], DEPOT_NAME)]
        column : list[int] = [0 for _ in range(column_size)]
        c_no = int(remaining_customers[0][1:])
        column[c_no] = 1
        column[nb_cust + c_no] = 1
        remaining_customers = remaining_customers[1:]
        columns.append(tuple(column))
    return columns

def main():
    settings_file = 'instance.xlsx'
    supp_amounts : dict[str, float] = get_supp_amount(settings_file)
    truck_cap : int = get_truck_cap(settings_file)
    min_collect : int = get_min_collect(settings_file)

    cust_coords : dict[str, tuple[float, float]] = get_cust_coords(settings_file)
    supp_coords : dict[str, tuple[float, float]] = get_supp_coords(settings_file)
    all_coords : dict[str, tuple[float, float]] = {l_ : cust_coords[l_] if l_ in cust_coords else supp_coords[l_] for l_ in list(cust_coords.keys()) + list(supp_amounts.keys())}

    distances : dict[tuple[str, str], float] = compute_distances(all_coords, cust_coords.keys(), supp_coords.keys())
    columns : list[tuple[int]] = generate_first_columns(distances, list(cust_coords.keys()), truck_cap, supp_amounts, min_collect)
    if columns is None:
        print('No column was generated.')
        return
    for philcol_ in columns:
        print(transform_column_to_arcs(philcol_, len(cust_coords), len(supp_coords)), get_collected_supply(philcol_, len(cust_coords), len(supp_coords), supp_amounts))

    print(f'Overall cost : {round(sum(get_cost(cust_coords, supp_coords, distances, philcol_) for philcol_ in columns), 3)}')
if __name__ == '__main__':
    main()