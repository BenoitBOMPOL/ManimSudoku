'''
    Create instance files
'''

import pandas as pd
import random as rd
from math import log10
import os

def build_instance(nb_customers : int,
         nb_suppliers : int,
         min_collect : int,
         truck_cap : int,
         out_folder : str):

    settings_df : pd.DataFrame = pd.DataFrame({'min_collect' : [min_collect], 'truck_cap' : [truck_cap]})
    customer_df : pd.DataFrame = pd.DataFrame(columns = ['custNo', 'locX', 'locY', 'demand'])
    nbz_cust = int(log10(nb_customers - 1)) + 1
    for i_ in range(nb_customers):
        x_cust, y_cust = rd.randint(0, 25), rd.randint(0, 25)
        i_demand = rd.randint(1, truck_cap - 1)
        cust_name = f'c{str(i_).zfill(nbz_cust)}'
        customer_df.loc[len(customer_df.index)] = [cust_name, x_cust, y_cust, i_demand]
    
    supplier_df : pd.DataFrame = pd.DataFrame(columns = ['suppNo', 'locX', 'locY', 'supply'])
    nbz_supp = 0
    if nb_suppliers > 0:
        nbz_supp = int(log10(nb_suppliers - 1)) + 1
    for j_ in range(nb_suppliers):
        x_supp, y_supp = rd.randint(0, 25), rd.randint(0, 25)
        supp_name = f's{str(j_).zfill(nbz_supp)}'
        supp_sply = rd.randint(1, truck_cap - 1)
        supplier_df.loc[len(supplier_df.index)] = [supp_name, x_supp, y_supp, supp_sply]

    output_filename = f'vrp_xlsx_instances/{out_folder}/{out_folder[0]}-n{nb_customers + nb_suppliers}-k{nb_customers}.xlsx'
    with pd.ExcelWriter(output_filename) as xlWriter:
        settings_df.to_excel(xlWriter, sheet_name = 'parameters',index = False)
        customer_df.to_excel(xlWriter, sheet_name = 'customers', index = False)
        supplier_df.to_excel(xlWriter, sheet_name = 'suppliers', index = False)

if __name__ == '__main__':
    N = [32,33,33,34,36,37,37,38,39,39,44,45,45,46,48,53]
    K = [5,5,6,5,5,5,6,5,5,6,6,6,7,7,7,7]
    rd.seed('42')
    ratio = input('\% of Q*C :')
    out_folder = 'D' + ratio
    os.mkdir(f'vrp_xlsx_instances/{out_folder}')
    for (n, k) in zip(N, K):
        NB_CUSTOMER = k
        NB_SUPPLIER = (n - k)
        TRUCK_CAP = 20
        MIN_COLLECT = int(int(ratio) * NB_CUSTOMER * TRUCK_CAP / 100)
        print(f'Creation of {out_folder[0]}-n{n}-k{k}...', end = ' ')
        build_instance(NB_CUSTOMER, NB_SUPPLIER, MIN_COLLECT, TRUCK_CAP, out_folder)
        print('Done !')